

const Post = ({post}) => {

}
export default Post