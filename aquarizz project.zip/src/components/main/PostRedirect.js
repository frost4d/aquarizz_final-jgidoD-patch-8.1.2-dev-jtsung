import { Box } from "@chakra-ui/react"


const PostRedirect = (props) => {


    return (
        <>
            <Box></Box>
        </>
    )

}
export default PostRedirect