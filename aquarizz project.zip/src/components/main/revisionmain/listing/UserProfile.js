import { Box } from "@chakra-ui/react";

const UserProfile = () => {
  return (
    <>
      <Box></Box>
    </>
  );
};
export default UserProfile;
