import { Box } from "@chakra-ui/react";
import "./Login.css";
const Login = () => {
  return (
    <>
      <Box></Box>
    </>
  );
};
export default Login;
