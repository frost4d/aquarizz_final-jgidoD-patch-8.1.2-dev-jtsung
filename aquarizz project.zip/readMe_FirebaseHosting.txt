npm i -g firebase-tools

firebase login

firebase init

firebase deploy